define('index/mod-taskBar', ['jquery'],function($){

	return{
		init:function(){
			console.log($);

		}
	}
})

